#!/usr/bin/env python3
"""Restore the 13-part source layout required by the roomier-holder builder.

The exported compact 12-part plate is preserved and object 13 is the original
button tray, centred at (40, 160) on the 256 mm plate. No slicing or printer I/O.
"""
from pathlib import Path
import struct
import zipfile
import xml.etree.ElementTree as ET
import numpy as np

BASE = Path(__file__).resolve().parent
KIT = BASE / 'button-support-pillar-rescue-20261031/compact'
SOURCE = KIT / '按钮托底承托柱-可调10至60mm-12件-轻量版.3mf'
TRAY = BASE / 'help-button-component-holders-20261031/button-holder.stl'
TARGET = KIT / '立柱加按钮小底托-13件-同一盘.3mf'
NS = 'http://schemas.microsoft.com/3dmanufacturing/core/2015/02'


def main():
    data = TRAY.read_bytes()
    count = struct.unpack_from('<I', data, 80)[0]
    assert len(data) == 84 + count * 50
    dtype = np.dtype([('normal', '<f4', (3,)), ('vertices', '<f4', (3, 3)), ('attribute', '<u2')])
    triangles = np.frombuffer(data, dtype=dtype, offset=84)['vertices']
    vertices, inverse = np.unique(triangles.reshape(-1, 3), axis=0, return_inverse=True)
    faces = inverse.reshape(-1, 3)
    with zipfile.ZipFile(SOURCE) as archive:
        entries = {name: archive.read(name) for name in archive.namelist()}
    text = entries['3D/3dmodel.model'].decode()
    root = ET.fromstring(text)
    assert len(root.findall(f'{{{NS}}}build/{{{NS}}}item')) == 12
    assert all(node.attrib['id'] != '13' for node in root.findall(f'{{{NS}}}resources/{{{NS}}}object'))
    obj = ['<object id="13" type="model" name="button-holder-13" pid="100" pindex="0"><mesh><vertices>']
    obj.extend('<vertex x="%.9g" y="%.9g" z="%.9g"/>' % tuple(point) for point in vertices)
    obj.append('</vertices><triangles>')
    obj.extend('<triangle v1="%d" v2="%d" v3="%d"/>' % tuple(face) for face in faces)
    obj.append('</triangles></mesh></object>')
    text = text.replace('</resources>', ''.join(obj) + '</resources>')
    text = text.replace('</build>', '<item objectid="13" transform="1 0 0 0 1 0 0 0 1 40 160 0"/></build>')
    entries['3D/3dmodel.model'] = text.encode()
    with zipfile.ZipFile(TARGET, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name, value in entries.items():
            archive.writestr(name, value)
    print(TARGET)


if __name__ == '__main__':
    main()
