#!/usr/bin/env python3
"""Sequential local geometry rebuild; --list by default, --run to write files."""
from pathlib import Path
import argparse
import subprocess
import sys

BASE = Path(__file__).resolve().parent
SCRIPTS = [
    'help-button-print-reference-20261030/printable-prototype-v1/build_prototype.py',
    'help-button-print-reference-20261030/printable-prototype-v1/black-pupils-20261031/build_pupils.py',
    'help-button-component-holders-20261031/build_holders.py',
    'esp32-holder-wire-clearance-v2-20261031/build_holder_v2.py',
    'help-button-enclosure-v2-20261031/build_enclosure_v2.py',
    'help-button-enclosure-v3-wide-20261031/build_enclosure_wide_v3.py',
    'help-button-enclosure-v3-wide-20261031/check_exported_geometry.py',
    'help-button-enclosure-v3-wide-20261031/render_preview.py',
    'help-button-mouth-20261031/build_mouth.py',
    'button-support-pillar-rescue-20261031/build_support_pillar_compact.py',
    'build_button_support_assembly.py',
    'button-support-pillar-rescue-20261031/button-holder-roomier-v2/build_roomier_button_holder.py',
    'help-button-model-kit-20261031/build_four_plates.py',
    'finalize_four_plate_support.py',
]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true', help='Rebuild files inside this models folder')
    parser.add_argument('--list', action='store_true', help='Show the build order without writing')
    args = parser.parse_args()
    for index, relative in enumerate(SCRIPTS, 1):
        assert (BASE / relative).is_file(), relative
        print(f'{index:02d}. {relative}', flush=True)
        if args.run and not args.list:
            subprocess.run([sys.executable, str(BASE / relative)], cwd=BASE, check=True)


if __name__ == '__main__':
    main()
