#!/usr/bin/env python3
"""Losslessly restore large STL payloads, checking the recorded source SHA-256."""
from pathlib import Path
import gzip
import hashlib
import json

BASE = Path(__file__).resolve().parent


def main():
    provenance = json.loads((BASE / 'source-copy-verification.json').read_text(encoding='utf-8'))
    for record in provenance['files']:
        if record.get('compression'):
            source = BASE / record['path']
            data = gzip.decompress(source.read_bytes())
            assert len(data) == record['uncompressed_size']
            assert hashlib.sha256(data).hexdigest() == record['uncompressed_sha256']
            target = source.with_suffix('')
            if target.exists() and target.read_bytes() != data:
                raise RuntimeError(f'Refusing to replace a different file: {target}')
            target.write_bytes(data)
            print(target)


if __name__ == '__main__':
    main()
