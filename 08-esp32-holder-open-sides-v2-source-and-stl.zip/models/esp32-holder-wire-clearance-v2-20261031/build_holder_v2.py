#!/usr/bin/env python3
"""Single screwless ESP32 cradle with open bottom/side channels, dimensions in mm.

Uses the existing prototype SDF/mesher. No machine preset, slicing or printer action.
Only supplied PCB outlines/hole locations are dimensioned; physical fit is unverified.
"""
from pathlib import Path
import sys
sys.dont_write_bytecode = True
import datetime
import hashlib
import importlib.util
import json
import struct
import zipfile
import xml.etree.ElementTree as ET
import numpy as np
from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
OLD = HERE.parent / 'help-button-component-holders-20261031'
TOOL = HERE.parent / 'help-button-print-reference-20261030/printable-prototype-v1/build_prototype.py'
spec = importlib.util.spec_from_file_location('prototype_sdf_tools', TOOL)
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)

PARAMS = {
    'units': 'mm', 'board_mm': [52.0, 28.0], 'recess_mm': [52.6, 28.6],
    'mount_hole_centres_mm': [47.0, 23.0], 'reference_pcb_hole_diameter_mm': 3.0,
    'reference_header_row_centres_y_mm': [-12.5, 12.5],
    'mounting_shoulder_diameter_mm': 4.2,
    'minimum_nominal_shoulder_to_slot_x_gap_mm': 1.4,
    'locating_pin_diameter_mm': 2.6, 'pin_top_z_mm': 5.8,
    'board_support_top_z_mm': 5.0, 'base_thickness_mm': 2.0,
    'outer_nominal_mm': [56.6, 32.6, 7.2], 'mesh_step_mm': 0.28,
    'side_slots': {'count': 2, 'x_interval_mm': [-20.0, 20.0],
                   'length_mm': 40.0, 'inner_y_abs_mm': 8.5,
                   'nominal_outer_edge_y_abs_mm': 16.3,
                   'cut_outer_y_abs_mm': 22.0, 'cut_z_interval_mm': [-1.0, 9.0],
                   'open_to_side_and_bottom': True},
    'central_spine_nominal_width_mm': 17.0,
    'end_support_zone_nominal_length_each_mm': 6.3,
    'usb_short_end_openings': {'count': 2, 'nominal_width_mm': 13.0, 'start_z_mm': 2.0},
    'screw_bosses': 0, 'screws': 0, 'clamps': 0, 'snap_locks': 0,
    'pin_function': 'location only; not a snap-lock or positive retention feature',
    'physical_pcb_or_connector_fit_verified': False,
    'installed_enclosure_clearance_verified': False,
}


def uncut_holder_field(x, y, z):
    """Old base/rail/pin dimensions, with screw bosses and clamp notches omitted."""
    px, py = 26.3, 14.3
    base = g.slabshape(x, y, z, px + 2, py + 2, 1.5, 0, 2.0)
    outer = g.slabshape(x, y, z, px + 2, py + 2, 1.5, 1.8, 7.2)
    pocket = g.box(x, y, z, (0, 0, 6), (px, py, 5))
    field = np.minimum(base, np.maximum(outer, -pocket))
    for sy in (-1, 1):
        rail = g.box(x, y, z, (0, sy*(py-.65), 3.45), (px, .65, 1.55))
        field = np.minimum(field, rail)
    for sx in (-1, 1):
        window = g.box(x, y, z, (sx*(px+1), 0, 7), (2.1, 6.5, 5))
        field = np.maximum(field, -window)
    for sx in (-1, 1):
        for sy in (-1, 1):
            xp, yp = x-sx*23.5, y-sy*11.5
            shoulder = g.cyl(xp, yp, z, 2.1, 1.9, 5.05)
            pin = g.cyl(xp, yp, z, 1.3, 4.95, 5.8)
            field = np.minimum(field, np.minimum(shoulder, pin))
    return field


def holder_field(x, y, z):
    field = uncut_holder_field(x, y, z)
    for sy in (-1, 1):
        # Extends past the outside wall and both Z faces: attached leads need not
        # be threaded through a closed hole before the PCB is lowered in place.
        channel = g.box(x, y, z, (0, sy*15.25, 4), (20.0, 6.75, 5.0))
        field = np.maximum(field, -channel)
    return field


def sample_geometry():
    result = {'slots': [], 'locating_pins': [], 'short_end_ports': []}
    for side in (-1, 1):
        xx, yy, zz = np.meshgrid(np.linspace(-19.8, 19.8, 101),
                                 side*np.linspace(8.7, 21.8, 51),
                                 np.linspace(-.8, 8.8, 37), indexing='ij')
        values = holder_field(xx, yy, zz)
        assert np.all(values > 0)
        # Confirm material formerly below the long pin rows is removed, not just
        # a cosmetic opening in an upper side wall.
        floor_x, floor_y = np.meshgrid(np.linspace(-19.5, 19.5, 80),
                                      side*np.linspace(8.8, 15.8, 25), indexing='ij')
        before = uncut_holder_field(floor_x, floor_y, np.ones_like(floor_x))
        after = holder_field(floor_x, floor_y, np.ones_like(floor_x))
        assert np.all(before < 0) and np.all(after > 0)
        # Requested envelope surrounding each 25 mm-spaced pin row: a volume,
        # not a thin hole or a slit that still traps an attached connector.
        row_x, row_y, row_z = np.meshgrid(np.linspace(-19, 19, 77),
                                        side*np.linspace(11, 15, 17),
                                        np.linspace(0, 7.2, 25), indexing='ij')
        row_values = holder_field(row_x, row_y, row_z)
        assert np.all(row_values > 0)
        result['slots'].append({'side_y_sign': side, 'interior_grid_samples': int(values.size),
                                'minimum_air_field_mm': float(values.min()),
                                'all_interior_samples_air': True,
                                'former_floor_removed_samples': int(before.size),
                                'requested_connector_envelope_mm': {'x': [-19, 19],
                                    'y_abs': [11, 15], 'z': [0, 7.2]},
                                'connector_envelope_volume_samples': int(row_values.size),
                                'all_connector_envelope_samples_air': True,
                                'open_through_z_and_outside_long_wall': True})
    angles = np.linspace(0, 2*np.pi, 72, endpoint=False)
    for sx in (-1, 1):
        for sy in (-1, 1):
            cx, cy = sx*23.5, sy*11.5
            # Sample strict interiors of the short 2.6 mm pin and its support.
            xx, zz = np.meshgrid(cx + 1.1*np.cos(angles), np.linspace(5.12, 5.65, 9), indexing='ij')
            yy = np.broadcast_to((cy + 1.1*np.sin(angles))[:, None], xx.shape)
            values = holder_field(xx, yy, zz)
            original = uncut_holder_field(xx, yy, zz)
            assert np.all(values < 0) and np.array_equal(values, original)
            assert float(holder_field(cx, cy, 3.0)) < 0
            bridge_x = sx*np.linspace(20.15, 21.35, 25)
            bridge_values = holder_field(bridge_x, np.full_like(bridge_x, cy), np.ones_like(bridge_x))
            assert np.all(bridge_values < 0)
            result['locating_pins'].append({'centre_xy_mm': [cx, cy],
                                            'interior_samples': int(values.size),
                                            'all_pin_samples_solid': True,
                                            'pin_field_unchanged_by_slots': True,
                                            'base_bridge_solid_samples': int(bridge_values.size),
                                            'support_present_at_z3': True})
    for side in (-1, 1):
        xx, yy, zz = np.meshgrid(side*np.linspace(25.3, 29.0, 21),
                                 np.linspace(-6.2, 6.2, 31), np.linspace(2.3, 6.9, 15), indexing='ij')
        values = holder_field(xx, yy, zz)
        assert np.all(values > 0)
        result['short_end_ports'].append({'side_x_sign': side, 'samples': int(values.size), 'all_air': True})
    spine_x, spine_y = np.meshgrid(np.linspace(-19.9, 19.9, 81), np.linspace(-8.2, 8.2, 41), indexing='ij')
    assert np.all(holder_field(spine_x, spine_y, np.ones_like(spine_x)) < 0)
    result['central_spine_solid_samples'] = int(spine_x.size)
    result['scope'] = 'Analytic source-field samples; not measured hardware fit or strength.'
    return result


def write_single_3mf(path, vertices, faces):
    ns = 'http://schemas.microsoft.com/3dmanufacturing/core/2015/02'
    lines = [f'<?xml version="1.0" encoding="UTF-8"?><model unit="millimeter" xml:lang="en-US" xmlns="{ns}">',
             '<metadata name="Title">ESP32 screwless open-side cradle V2</metadata><resources>',
             '<basematerials id="100"><base name="Cream reference only" displaycolor="#F4E4C9"/></basematerials>',
             '<object id="1" name="esp32-holder-open-sides-v2" type="model" pid="100" pindex="0"><mesh><vertices>']
    lines.extend('<vertex x="%.5f" y="%.5f" z="%.5f"/>' % tuple(v) for v in vertices)
    lines.append('</vertices><triangles>')
    lines.extend('<triangle v1="%d" v2="%d" v3="%d"/>' % tuple(f) for f in faces)
    lines.append('</triangles></mesh></object></resources><build><item objectid="1" transform="1 0 0 0 1 0 0 0 1 100 100 0"/></build></model>')
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('[Content_Types].xml', '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>')
        archive.writestr('_rels/.rels', '<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>')
        archive.writestr('3D/3dmodel.model', ''.join(lines))
    with zipfile.ZipFile(path) as archive:
        xml = ET.fromstring(archive.read('3D/3dmodel.model'))
        objects = xml.findall(f'{{{ns}}}resources/{{{ns}}}object')
        items = xml.findall(f'{{{ns}}}build/{{{ns}}}item')
        assert len(objects) == len(items) == 1
        assert not any('gcode' in name.lower() or 'config' in name.lower() for name in archive.namelist())
    return {'object_count': 1, 'build_item_count': 1, 'model_only': True,
            'machine_preset_present': False, 'gcode_present': False,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def triangles_from_binary_stl(path):
    data = path.read_bytes()
    count = struct.unpack_from('<I', data, 80)[0]
    assert len(data) == 84 + 50*count
    dtype = np.dtype([('normal', '<f4', (3,)), ('vertices', '<f4', (3, 3)), ('attribute', '<u2')])
    return np.frombuffer(data, dtype=dtype, offset=84, count=count)['vertices'].astype(float)


def render(triangles, image, box, camera):
    camera = np.array(camera, dtype=float); camera /= np.linalg.norm(camera)
    right = np.cross([0, 0, 1], camera); right /= np.linalg.norm(right)
    up = np.cross(camera, right)
    normals = np.cross(triangles[:, 1]-triangles[:, 0], triangles[:, 2]-triangles[:, 0])
    normals /= np.maximum(np.linalg.norm(normals, axis=1)[:, None], 1e-12)
    visible = normals@camera > 1e-9
    triangles, normals = triangles[visible], normals[visible]
    projection = np.stack((triangles@right, -(triangles@up)), axis=-1)
    lo, hi = projection.min(axis=(0, 1)), projection.max(axis=(0, 1))
    x, y, width, height = box
    scale = min(width/(hi[0]-lo[0]), height/(hi[1]-lo[1]))
    projection = (projection-(lo+hi)/2)*scale + [x+width/2, y+height/2]
    light = np.array([-.4, -.7, 1]); light /= np.linalg.norm(light)
    brightness = .50 + .50*np.maximum(normals@light, 0)
    colours = np.clip(np.array([244, 228, 201])[None, :]*brightness[:, None], 0, 255).astype(int)
    order = np.argsort((triangles@camera).mean(axis=1))
    draw = ImageDraw.Draw(image)
    for index in order:
        draw.polygon([tuple(p) for p in projection[index]], fill=tuple(colours[index]))


def preview(stl_path):
    tris = triangles_from_binary_stl(stl_path)
    image = Image.new('RGB', (1800, 1200), '#F4F3EE'); draw = ImageDraw.Draw(image)
    font = '/System/Library/Fonts/STHeiti Medium.ttc'
    title = ImageFont.truetype(font, 48); regular = ImageFont.truetype(font, 29); small = ImageFont.truetype(font, 26)
    draw.text((60, 32), 'ESP32 托座 V2 · 无螺丝版', font=title, fill='#24452D')
    draw.text((60, 105), '两侧开放走线：长边侧壁和底板一起让开', font=regular, fill='#475647')
    draw.rounded_rectangle((40, 175, 1090, 900), 26, fill='white')
    draw.rounded_rectangle((1120, 175, 1760, 900), 26, fill='white')
    draw.text((75, 205), '实际网格 · 立体视图', font=regular, fill='#24452D')
    render(tris, image, (95, 300, 940, 510), (.28, -.7, 1.05))
    draw.text((1150, 205), '俯视 · 中央脊与两端支承', font=regular, fill='#24452D')
    render(tris, image, (1155, 335, 570, 420), (.001, -.001, 1.0))
    draw.text((60, 942), '两条 40 mm 长开放槽 · 保留 4 个定位柱与两端接口', font=regular, fill='#24452D')
    draw.text((60, 1000), '单件托座；没有螺丝、压片或卡扣，定位柱仅定位。', font=regular, fill='#475647')
    draw.text((60, 1061), '参考板 52×28 mm，孔距 47×23 mm；伸出底面的插头还需要壳内空间。', font=small, fill='#475647')
    draw.text((60, 1120), '未实物试装 · 未切片 · 未发送打印；请先核对实际板卡和插头尺寸。', font=small, fill='#6F493C')
    path = HERE/'ESP32托座V2-无螺丝-实际网格预览.png'
    image.save(path)
    return {'path': str(path), 'basis': 'actual exported binary STL triangles',
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def main():
    originals = [OLD/name for name in ['build_holders.py', 'esp32-holder.stl', 'coarse-screw.stl', 'edge-clamp.stl', 'plate-1-esp32.3mf']]
    original_hashes = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in originals}
    samples = sample_geometry()
    print('Source slot, pin and end-port samples passed; meshing single screwless holder...', flush=True)
    vertices, faces = g.mesh(holder_field, [(-29, 29), (-17, 17), (-.2, 7.7)], PARAMS['mesh_step_mm'])
    stats = g.validate(vertices, faces)
    assert stats['boundary_edges'] == stats['nonmanifold_edges'] == 0
    assert stats['surface_components'] == 1 and stats['signed_volume_mm3'] > 0
    assert vertices[:, 2].min() >= -1e-6
    stl = HERE/'esp32-holder-open-sides-v2.stl'
    g.stl(stl, vertices, faces)
    three_mf = HERE/'ESP32托座V2-无螺丝-双侧走线.3mf'
    archive = write_single_3mf(three_mf, vertices, faces)
    image_report = preview(stl)
    assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == sha for p, sha in original_hashes.items())
    report = {'timestamp_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'parameters': PARAMS, 'mesh': stats, 'geometry_point_samples': samples,
              'stl': {'path': str(stl), 'bytes': stl.stat().st_size, 'sha256': hashlib.sha256(stl.read_bytes()).hexdigest()},
              'three_mf': archive, 'preview': image_report,
              'original_artifact_sha256_unchanged': original_hashes,
              'sliced': False, 'printer_command_sent': False,
              'physical_fit_verified': False, 'thread_features_present': False,
              'limitations': ['No snap-lock or screws: pins locate but do not positively retain the PCB.',
                             '40 mm slot span and connector envelopes need physical measurement.',
                             'Connectors extending below Z=0 require free space or spacing inside the outer enclosure.',
                             'No main-enclosure mounting interface or calibrated button mechanism added.',
                             'Topology and analytic samples do not prove strength, self-intersection freedom or physical printability.']}
    (HERE/'validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    (HERE/'说明.txt').write_text('''ESP32 托座 V2 · 无螺丝、双侧开放走线

文件：ESP32托座V2-无螺丝-双侧走线.3mf（单个托座模型）；esp32-holder-open-sides-v2.stl。
只针对 ESP32 托座，不是按钮模块托座。旧件未修改。

参考板 52×28 mm，四孔中心距 47×23 mm、孔径3 mm。凹槽参考尺寸52.6×28.6 mm，托座外廓约56.6×32.6×7.2 mm。
两排排针参考跨距25 mm（中线两侧各12.5 mm），与四个安装孔的23 mm跨距是不同尺寸。
两条长边各有一条40 mm长的开放槽，从距中线8.5 mm处一直开到侧边，底板与侧壁上下贯通。
中央保留17 mm宽底脊，两端保留支承；四个2.6 mm短定位柱、两端中间接口缺口保留。
无螺纹耳座、无螺丝、无压片，也没有按未知板厚增加卡扣；四柱只用于定位，不保证锁住电路板。

装配：凹槽朝上，元件朝上，四孔对准短柱轻放。两排已接的杜邦线从两侧开放槽绕出，不需要先穿闭孔。
开放槽不能保证适合任意排针/插头；实际板型、排针位置、插头外壳长度仍需核对，碰到就停下，不硬压。
下方伸出托座底面的插头，需要主壳内部另外有高度空间；不能直接把托座压在插头上，也未承诺平贴主壳底部。

颜色仅为参考；模型为毫米单位、平底朝下。3MF不含打印机预设或G-code。
尚未实物试装、未切片、未发送打印；未修改或启动任何打印机任务。
validation.json记录网格闭合/连通/体积及槽口、定位柱、接口点采样；它不等于实物配合或承力验证。
''')
    print(json.dumps({'mesh': stats, 'stl': str(stl), 'three_mf': str(three_mf), 'preview': image_report['path']}, ensure_ascii=False, indent=2), flush=True)


if __name__ == '__main__':
    HERE.mkdir(parents=True, exist_ok=True)
    main()
